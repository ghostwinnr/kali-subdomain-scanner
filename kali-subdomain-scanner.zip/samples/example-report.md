# Örnek Rapor

- Subdomainler: 12
- Canlı hostlar: 5
- Nuclei bulguları: 3 (low/medium/high)

Bu örnek rapor sadece gösterim amaçlıdır.
